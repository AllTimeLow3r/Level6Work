const studentNamesCollection = [

    'Aidan',
    'Cody',
    'Daniel',
    'Jerry',
    'Liam',
    'David',
    'Emanuel',
    'Ethan',
    'Haiden',
    'Harry',
    'Jasiu',
    'Jean',
    'Kaidyn',
    'Leah',
    'Michael',
    'Rowan',
    'Ryder',
    'Stefan',
    'Vaida',
    'Andrew',
    'Thomas'
]

studentNamesCollection.sort();

console.log(studentNamesCollection);

chooseName = parseInt(prompt(`Choose a number from 0 - ${studentNamesCollection.length}`));

if (chooseName > 0 && chooseName < 21) {
    document.write(`That number is associated with ${studentNamesCollection[chooseName]}`);
} else {
    alert('Pick a number between 0-21!');
    location.reload();
}