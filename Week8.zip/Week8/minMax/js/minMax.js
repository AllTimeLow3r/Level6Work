const numbersCollection = [
    5,
    4,
    1,
    6,
    2
]

minNum = 100;
maxNum = 0;

document.write('All the numbers inside the array are <br>')
for (i=0; i < numbersCollection.length; i++){
    document.write(`${[i]}. ${numbersCollection[i]} <br>`);
}

minNum = Math.min(5,4,1,6,2);
maxNum = Math.max(5,4,1,6,2);

document.write(`The min number is ${minNum}, the maximum number is ${maxNum}`);